import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:uuid/uuid.dart';

class CardScreen extends StatefulWidget {
  @override
  _CardScreenState createState() => _CardScreenState();
}

class _CardScreenState extends State<CardScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController jobController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController websiteController = TextEditingController();

  String? qrData;
  File? _image;
  final ImagePicker _picker = ImagePicker();

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<void> _saveToFirebase() async {
    if (nameController.text.isEmpty ||
        jobController.text.isEmpty ||
        phoneController.text.isEmpty ||
        emailController.text.isEmpty ||
        websiteController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("All fields must be filled")),
      );
      return;
    }

    // Get current user ID
    String? userID = FirebaseAuth.instance.currentUser?.uid;
    if (userID == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("User not logged in!")),
      );
      return;
    }

    // Generate unique card ID
    String cardID = Uuid().v4();

    // Prepare QR data
    String data =
        "Name: ${nameController.text}\nJob: ${jobController.text}\nPhone: ${phoneController.text}\nEmail: ${emailController.text}\nWebsite: ${websiteController.text}";

    setState(() {
      qrData = data;
    });

    // Save to Firestore
    await FirebaseFirestore.instance.collection('cards').doc(cardID).set({
      'userId': userID, // Add userId field
      'name': nameController.text,
      'job': jobController.text,
      'mobile': phoneController.text,
      'email': emailController.text,
      'website': websiteController.text,
      'qrData': data,
      'createdAt': FieldValue.serverTimestamp(), // Optional for sorting
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Card saved successfully!")),
    );
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          ColorFiltered(
            colorFilter: ColorFilter.mode(
              Colors.black.withOpacity(0.6),
              BlendMode.darken,
            ),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("images/bg.jpg"),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(16.0),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: Icon(Icons.arrow_back, color: Color(0xFFFFD700)),
                        onPressed: () => Navigator.pop(context),
                      ),
                      Text(
                        "Create Business Card",
                        style: TextStyle(
                          color: Color(0xFFFFD700),
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(width: 40),
                    ],
                  ),
                  SizedBox(height: 20),
                  GestureDetector(
                    onTap: _pickImage,
                    child: CircleAvatar(
                      radius: 80,
                      backgroundColor: Colors.black,
                      backgroundImage:
                          _image != null ? FileImage(_image!) : null,
                      child: _image == null
                          ? Icon(Icons.camera_alt, color: Color(0xFFFFD700))
                          : null,
                    ),
                  ),
                  SizedBox(height: 20),
                  _buildTextField(nameController, "Full Name", Icons.person),
                  _buildTextField(jobController, "Job Title", Icons.work),
                  _buildTextField(phoneController, "Phone Number", Icons.phone),
                  _buildTextField(emailController, "Email", Icons.email),
                  _buildTextField(websiteController, "Website", Icons.web),
                  SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _saveToFirebase,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFFFFD700),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 16),
                      ),
                      child: Text(
                        "Save & Generate QR",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  if (qrData != null)
                    Center(
                      child: Container(
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.7),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: QrImageView(
                          data: qrData!,
                          version: QrVersions.auto,
                          size: 200.0,
                          backgroundColor: Colors.white,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller, String hint, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        style: TextStyle(color: Color(0xFFFFD700)),
        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.black.withOpacity(0.7),
          hintText: hint,
          hintStyle: TextStyle(color: Color(0xFFFFD700).withOpacity(0.5)),
          prefixIcon: Icon(icon, color: Color(0xFFFFD700)),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }
}
