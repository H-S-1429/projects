import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import 'digitalBusinessCard.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<DocumentSnapshot> cards = [];

  @override
  void initState() {
    super.initState();
    fetchCards();
  }

  void fetchCards() async {
    String? userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) return;

    QuerySnapshot querySnapshot = await _firestore
        .collection('cards')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .get();

    setState(() {
      cards = querySnapshot.docs.toList();
    });
  }

  void deleteCard(String docId) async {
    await _firestore.collection('cards').doc(docId).delete();
    fetchCards();
  }

  void signOut() async {
    await _auth.signOut();
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          ColorFiltered(
            colorFilter: ColorFilter.mode(
              Colors.black.withOpacity(0.6),
              BlendMode.darken,
            ),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("images/bg.jpg"),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Cards",
                      style: TextStyle(
                        color: Color(0xFFFFD700),
                        fontSize: 45,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                      ),
                    ),
                    PopupMenuButton(
                      icon: CircleAvatar(
                        backgroundColor: Color(0xFFFFD700),
                        child: Icon(Icons.person, color: Colors.black),
                      ),
                      itemBuilder: (context) => [
                        PopupMenuItem(
                          child: Text("About"),
                          value: 'about',
                        ),
                        PopupMenuItem(
                          child: Text("Sign Out"),
                          value: 'logout',
                        ),
                      ],
                      onSelected: (value) {
                        if (value == 'about') {
                          showAboutDialog(
                            context: context,
                            applicationName: "Digital Business Card",
                            applicationVersion: "1.0.0",
                            children: [Text("Created by You")],
                          );
                        } else if (value == 'logout') {
                          signOut();
                        }
                      },
                    ),
                  ],
                ),
                Expanded(
                  child: cards.isEmpty
                      ? Center(
                          child: Text(
                            "No cards found",
                            style: TextStyle(color: Colors.white),
                          ),
                        )
                      : ListView.builder(
                          padding: EdgeInsets.all(16),
                          itemCount: cards.length,
                          itemBuilder: (context, index) {
                            var cardData =
                                cards[index].data() as Map<String, dynamic>;
                            String docId = cards[index].id;
                            return Dismissible(
                              key: Key(docId),
                              background: Container(
                                color: Colors.red,
                                alignment: Alignment.centerRight,
                                padding: EdgeInsets.symmetric(horizontal: 20),
                                child: Icon(Icons.delete, color: Colors.white),
                              ),
                              onDismissed: (direction) {
                                deleteCard(docId);
                              },
                              child: CardTile(cardData),
                            );
                          },
                        ),
                ),
                SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => CardScreen()),
                        ).then((value) {
                          if (value == true) {
                            fetchCards();
                          }
                        });
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFFFFD700),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 16),
                      ),
                      child: Text(
                        "Add New",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class CardTile extends StatelessWidget {
  final Map<String, dynamic> cardData;
  CardTile(this.cardData);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 12),
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            cardData['name'] ?? "Unknown",
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 18,
              color: Color(0xFFFFD700),
            ),
          ),
          SizedBox(height: 5),
          Text(
            "${cardData['job'] ?? ''}\n${cardData['mobile'] ?? ''}\n${cardData['email'] ?? ''}",
            style: TextStyle(color: Colors.white, fontSize: 14),
          ),
          Align(
            alignment: Alignment.centerRight,
            child: IconButton(
              icon: Icon(Icons.qr_code, color: Color(0xFFFFD700), size: 30),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    content: QrImageView(
                      data: cardData['qrData'] ?? '',
                      version: QrVersions.auto,
                      size: 200.0,
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
